#include <iostream>
#include <SFML/Graphics.hpp>

#include "game.hpp"

int main()
{


	Game newGame{};
	newGame.Play();

	return 0;
}