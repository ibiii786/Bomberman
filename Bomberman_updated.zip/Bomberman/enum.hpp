#pragma once

enum States { stand, movingLeft, movingRight, movingUp, movingDown };

enum BlockType { solidBlock, breakableBlock, backgroundBlock, bombBlock, explosionBlock};