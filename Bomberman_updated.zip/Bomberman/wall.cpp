#include <iostream>
#include <SFML/Graphics.hpp>

#include "wall.hpp"

void Wall::SetUp()
{
	std::cout << "Wrong pointer! Use BreakableWall or SolidWall or Background. " << std::endl;
}
